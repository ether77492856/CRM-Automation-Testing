from selenium.webdriver.common.by import By

from CRM.baseDir.base_page import BasePage


# 页面具体操作类
class CRMPage(BasePage):
    un = (By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[2]/form/div[1]/div/div/input')
    pw = (By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[2]/form/div[2]/div/div/input')
    bt = (By.XPATH, '//*[@id="app"]/div[1]/div[2]/div[2]/div/div[2]/div[3]/div')
    business = (By.XPATH, '//*[@id="app"]/section/section/div/div[2]/div[1]/div/ul/div[6]/a/li/div/span')
    seach = (By.XPATH, '//*[@id="crm-main-container"]/div/div/div[1]/div[2]/input')
    seach1 = (By.XPATH, '//*[@id="crm-main-container"]/div/div/div[1]/div[2]/div/button/span')
    text = (By.XPATH, '//*[@id="crm-table"]/div[4]/div[2]/div/div/table/tbody/tr[1]/td[2]/div/div/span')
    add = (By.XPATH, '//*[@id="crm-main-container"]/div/div/div[1]/div[3]/button')
    bn = (By.XPATH, '/html/body/div[5]/div/div/div/div[2]/div/div[2]/form/div[1]/div[1]/div/div[1]/input')
    date = (By.XPATH, '/html/body/div[5]/div/div/div/div[2]/div/div[2]/form/div[3]/div[2]/div/div[1]/input')
    ke = (By.XPATH, '/html/body/div[5]/div/div/div/div[2]/div/div[2]/form/div[1]/div[2]/div/div/span/span/div')
    bs=(By.XPATH,'/html/body/div[5]/div/div/div/div[2]/div/div[2]/form/div[2]/div[1]/div/div[1]/div/div/input')
    sy=(By.CSS_SELECTOR,' div.el-select-dropdown.el-popper:nth-child(11) div.el-scrollbar div.el-select-dropdown__wrap.el-scrollbar__wrap:nth-child(1) ul.el-scrollbar__view.el-select-dropdown__list > li.el-select-dropdown__item.selected.hover')
    save=(By.XPATH,'/html/body/div[5]/div/div/div/div[3]/button[2]/span')
    tag=(By.CSS_SELECTOR,'body:nth-child(2) div.el-message.el-message--success:nth-child(10) > p.el-message__content')
    dian=(By.XPATH,'//*[@id="crm-table"]/div[4]/div[2]/div/div/table/tbody/tr/td[1]/div/label/span/span')
    delete=(By.XPATH,'//*[@id="crm-main-container"]/div/div/div[2]/div[1]/div[2]/div[2]/button[3]/span')
    but=(By.XPATH,'/html/body/div[5]/div/div[3]/button[2]/span')
    tagd=(By.CSS_SELECTOR,'body:nth-child(2) div.el-message.el-message--success:nth-child(11) > p.el-message__content')
    def text_clear(self,qing):
        self.clears(qing)

    def clicks(self, cl):
        self.click(cl)

    def send_text(self, username, passwod):
        self.send_key(self.un, username)
        self.send_key(self.pw, passwod)
    def send_keys(self):
        self.jianpan(self.bs)
    def send_seach(self, bu):
        self.send_key(self.seach, bu)

    def buiness_text(self,ck):
        return self.texts(ck)

    def business_add(self, um, da):
        self.send_key(self.bn, um)
        self.send_key(self.date, da)

    def get(self):
        s = self.el(self.ke)
        dui = (By.XPATH,
               '//*[@id="' + s + '"]/div[1]/div[2]/div/div/div[2]/div[3]/table/tbody/tr[1]/td[1]/div/label/span/span')

        return dui
    def que(self):
        d=self.el(self.ke)
        que = (By.XPATH, '//*[@id="' + d + '"]/div[1]/div[3]/button[2]/span')
        return que