import yaml
class yaml1:
    def read(self):
        f = open(r"./data/1.yml", "r", encoding="utf8")
        l=yaml.safe_load(f)
        return l
# l=yaml1()
# print(l.read())