from selenium.webdriver import Keys
from selenium.webdriver.support.wait import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC

# 页面基类
class BasePage(object):
    def __init__(self, driver):
        self.driver = driver

    def find_elementl(self, loc):
        try:
            # return WebDriverWait(self.driver, 5).until(lambda x: x.find_element(*loc))
            el = WebDriverWait(self.driver, 15).until(EC.presence_of_element_located(loc))
            return el
        except:
            return print("fail")

    def click(self, loc):
        self.find_elementl(loc).click()

    def send_key(self, loc, strs):
        self.find_elementl(loc).send_keys(strs)
    def jianpan(self,loc):
        self.find_elementl(loc).send_keys(Keys.ARROW_DOWN,Keys.ENTER)
    def clears(self, loc):
        self.find_elementl(loc).clear()
    def texts(self,loc):
        return self.find_elementl(loc).text
    def el(self,loc):
        return self.find_elementl(loc).get_attribute('aria-describedby')
