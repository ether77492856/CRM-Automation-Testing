import time

from selenium import webdriver

# 测试基类
class TestBase():
    driver = None

    def setup_class(self):
        self.driver = webdriver.Edge()
        self.driver.maximize_window()

    def teardown_class(self):
        time.sleep(15)
        self.driver.quit()

