import pytest

# 运行类
if __name__ == '__main__':
    pytest.main(['./scriptsDir','-vs'])
