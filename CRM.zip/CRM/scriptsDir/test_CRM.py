import time

import pytest
from CRM.pageDir.page_CRM import CRMPage
from CRM.baseDir.test_base import TestBase
from CRM.baseDir.base_jieya import yaml1


# 测试类 各种测试类

class Test_Vhr(TestBase):

    @pytest.mark.parametrize("di", yaml1().read())
    def test_login(self,di):
        global crm
        global ti
        ti=str (int(time.time()))
        crm = CRMPage(self.driver)
        self.driver.get('http://127.0.0.1:10027/72crm/index.html#/login')
        crm.send_text(di["us"], di["pw"])  # 可以进行数据驱动实现参数化
        crm.clicks(crm.bt)  #点击登录
        time.sleep(2)
        assert self.driver.current_url== 'http://127.0.0.1:10027/72crm/index.html#/crm/workbench'

    def test_seach(self):     # 商机模块的搜索
        # bu=CRMPage(self.driver)
        crm.clicks(crm.business)
        crm.send_seach('名-1')
        crm.clicks(crm.seach1)
        time.sleep(2)
        assert crm.buiness_text(crm.text)==str('名-1')  #检验要搜索的内容与实际内容是否一致
    def test_add(self):    
        crm.clicks(crm.add)
        crm.business_add(ti,'2022-07-05')
        crm.clicks(crm.ke)
        crm.clicks(crm.get())
        crm.clicks(crm.que())
        crm.clicks(crm.bs)
        crm.send_keys()
        crm.clicks(crm.save)
        assert crm.buiness_text(crm.tag)==str('添加成功')
    def test_del(self):
        crm.text_clear(crm.seach)
        crm.send_seach(ti)
        crm.clicks(crm.seach1)
        crm.clicks(crm.dian)
        crm.clicks(crm.delete)
        crm.clicks(crm.but)
        assert crm.buiness_text(crm.tagd)==str('删除成功')